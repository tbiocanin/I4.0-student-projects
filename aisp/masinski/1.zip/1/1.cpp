#include <iostream>

int main() {

    std::string s = "Dobar dan 123456";

    int x = -0;
    std::cout << x << "\n";
    return 0;
}